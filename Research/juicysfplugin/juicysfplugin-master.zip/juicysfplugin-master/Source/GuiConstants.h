#pragma once

struct GuiConstants {
    inline static const int minWidth = 500;
    inline static const int maxWidth = 1900;
    inline static const int minHeight = 300;
    inline static const int maxHeight = 1000;
};
