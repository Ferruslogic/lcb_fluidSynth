//
// Created by Alex Birch on 17/09/2017.
//

#pragma once

#include "Preset.h"
#include <map>

typedef std::multimap<int, Preset> BanksToPresets;