xplatform

These are for Cross Plaform development on Windows : making a Macintosh projector on a Windows machine. Please read the documentation for usage details.


